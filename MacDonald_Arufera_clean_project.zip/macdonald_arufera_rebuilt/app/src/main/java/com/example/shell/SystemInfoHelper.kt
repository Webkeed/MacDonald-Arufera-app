package com.example.shell

import android.app.ActivityManager
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Build
import android.os.Environment
import android.os.StatFs
import android.os.SystemClock
import java.net.Inet4Address
import java.net.NetworkInterface
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.TimeUnit

data class SystemStats(
    val batteryPercent: Int,
    val isCharging: Boolean,
    val usedRamMb: Long,
    val totalRamMb: Long,
    val freeStorageGb: Double,
    val totalStorageGb: Double,
    val uptimeFormatted: String,
    val networkStatus: String,
    val ipAddress: String,
    val currentTime: String
)

object SystemInfoHelper {

    fun getStats(context: Context): SystemStats {
        val batteryInfo = getBatteryInfo(context)
        val ramInfo = getRamInfo(context)
        val storageInfo = getStorageInfo()
        val uptime = getFormattedUptime()
        val (netStatus, ip) = getNetworkInfo(context)
        val time = SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(Date())

        return SystemStats(
            batteryPercent = batteryInfo.first,
            isCharging = batteryInfo.second,
            usedRamMb = ramInfo.first,
            totalRamMb = ramInfo.second,
            freeStorageGb = storageInfo.first,
            totalStorageGb = storageInfo.second,
            uptimeFormatted = uptime,
            networkStatus = netStatus,
            ipAddress = ip,
            currentTime = time
        )
    }

    private fun getBatteryInfo(context: Context): Pair<Int, Boolean> {
        return try {
            val filter = IntentFilter(Intent.ACTION_BATTERY_CHANGED)
            val intent = context.registerReceiver(null, filter)
            val level = intent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = intent?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
            val status = intent?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
            val isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING ||
                    status == BatteryManager.BATTERY_STATUS_FULL
            val pct = if (level >= 0 && scale > 0) (level * 100) / scale else 100
            Pair(pct, isCharging)
        } catch (_: Exception) {
            Pair(100, false)
        }
    }

    private fun getRamInfo(context: Context): Pair<Long, Long> {
        return try {
            val actManager = context.getSystemService(Context.ACTIVITY_SERVICE) as ActivityManager
            val memInfo = ActivityManager.MemoryInfo()
            actManager.getMemoryInfo(memInfo)
            val totalMb = memInfo.totalMem / (1024 * 1024)
            val freeMb = memInfo.availMem / (1024 * 1024)
            Pair(totalMb - freeMb, totalMb)
        } catch (_: Exception) {
            Pair(512L, 2048L)
        }
    }

    private fun getStorageInfo(): Pair<Double, Double> {
        return try {
            val path = Environment.getDataDirectory()
            val stat = StatFs(path.path)
            val blockSize = stat.blockSizeLong
            val totalBlocks = stat.blockCountLong
            val availableBlocks = stat.availableBlocksLong

            val totalGb = (totalBlocks * blockSize).toDouble() / (1024.0 * 1024.0 * 1024.0)
            val freeGb = (availableBlocks * blockSize).toDouble() / (1024.0 * 1024.0 * 1024.0)
            Pair(Math.round(freeGb * 10.0) / 10.0, Math.round(totalGb * 10.0) / 10.0)
        } catch (_: Exception) {
            Pair(16.0, 64.0)
        }
    }

    private fun getFormattedUptime(): String {
        val uptimeMillis = SystemClock.elapsedRealtime()
        val hours = TimeUnit.MILLISECONDS.toHours(uptimeMillis)
        val minutes = TimeUnit.MILLISECONDS.toMinutes(uptimeMillis) % 60
        return "${hours}h ${minutes}m"
    }

    private fun getNetworkInfo(context: Context): Pair<String, String> {
        return try {
            val cm = context.getSystemService(Context.CONNECTIVITY_SERVICE) as ConnectivityManager
            val network = cm.activeNetwork
            val caps = cm.getNetworkCapabilities(network)

            val status = when {
                caps == null -> "Offline"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "Cellular"
                caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "Ethernet"
                else -> "Connected"
            }

            var ip = "127.0.0.1"
            val interfaces = NetworkInterface.getNetworkInterfaces()
            while (interfaces.hasMoreElements()) {
                val iface = interfaces.nextElement()
                val addrs = iface.inetAddresses
                while (addrs.hasMoreElements()) {
                    val addr = addrs.nextElement()
                    if (!addr.isLoopbackAddress && addr is Inet4Address) {
                        ip = addr.hostAddress ?: ip
                        break
                    }
                }
            }

            Pair(status, ip)
        } catch (_: Exception) {
            Pair("Unknown", "127.0.0.1")
        }
    }

    fun evaluateMath(expr: String): Double? {
        return try {
            val sanitized = expr.replace(" ", "")
            parseExpression(sanitized)
        } catch (_: Exception) {
            null
        }
    }

    private fun parseExpression(expr: String): Double {
        var pos = -1
        var ch = -1

        fun nextChar() {
            ch = if (++pos < expr.length) expr[pos].code else -1
        }

        fun eat(charToEat: Int): Boolean {
            while (ch == ' '.code) nextChar()
            if (ch == charToEat) {
                nextChar()
                return true
            }
            return false
        }

        fun parseFactor(): Double {
            if (eat('+'.code)) return parseFactor()
            if (eat('-'.code)) return -parseFactor()

            var x: Double
            val startPos = pos
            if (eat('('.code)) {
                x = parseFactor()
                while (eat('+'.code) || eat('-'.code) || eat('*'.code) || eat('/'.code) || eat('^'.code)) {
                    // handled by callers
                }
                eat(')'.code)
            } else if ((ch in '0'.code..'9'.code) || ch == '.'.code) {
                while ((ch in '0'.code..'9'.code) || ch == '.'.code) nextChar()
                x = expr.substring(startPos, pos).toDouble()
            } else {
                throw RuntimeException("Unexpected: " + ch.toChar())
            }

            if (eat('^'.code)) x = Math.pow(x, parseFactor())
            return x
        }

        fun parseTerm(): Double {
            var x = parseFactor()
            while (true) {
                when {
                    eat('*'.code) -> x *= parseFactor()
                    eat('/'.code) -> x /= parseFactor()
                    eat('%'.code) -> x %= parseFactor()
                    else -> return x
                }
            }
        }

        fun parse(): Double {
            nextChar()
            var x = parseTerm()
            while (true) {
                when {
                    eat('+'.code) -> x += parseTerm()
                    eat('-'.code) -> x -= parseTerm()
                    else -> return x
                }
            }
        }

        return parse()
    }
}
