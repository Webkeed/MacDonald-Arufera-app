package com.example.shell

import android.app.Application
import android.os.Build
import androidx.compose.ui.graphics.Color
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.apps.AppItem
import com.example.apps.AppLauncherManager
import com.example.data.db.AliasEntity
import com.example.data.db.AruferaDatabase
import com.example.data.db.CommandHistoryEntity
import com.example.matrix.MatrixColorTheme
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.Locale

data class TerminalUiState(
    val lines: List<TerminalLine> = emptyList(),
    val input: String = "",
    val isExecuting: Boolean = false,
    val showAppDrawer: Boolean = false,
    val isFullScreenMatrix: Boolean = false,
    val isMatrixBackgroundEnabled: Boolean = true,
    val matrixSpeed: Float = 1.0f,
    val matrixOpacity: Float = 0.40f,
    val matrixTheme: MatrixColorTheme = MatrixColorTheme.PHOSPHOR_GREEN,
    val fontSizeSp: Int = 13,
    val isCrtScanlines: Boolean = true,
    val historyIndex: Int = -1,
    val stats: SystemStats? = null,
    val pinnedApps: Set<String> = emptySet()
)

class TerminalViewModel(application: Application) : AndroidViewModel(application) {

    private val db = AruferaDatabase.getInstance(application)
    private val historyDao = db.historyDao()
    private val aliasDao = db.aliasDao()
    private val shellExecutor = ShellExecutor(application)
    val appLauncherManager = AppLauncherManager(application)

    private val _uiState = MutableStateFlow(TerminalUiState())
    val uiState: StateFlow<TerminalUiState> = _uiState.asStateFlow()

    private val _installedApps = MutableStateFlow<List<AppItem>>(emptyList())
    val installedApps: StateFlow<List<AppItem>> = _installedApps.asStateFlow()

    val commandHistory = historyDao.getAllHistory()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    val aliases = aliasDao.getAllAliases()
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    private var localHistoryCache = mutableListOf<String>()

    init {
        loadApps()
        startStatsTicker()
        displayWelcomeBanner()
    }

    private fun loadApps() {
        viewModelScope.launch {
            val apps = appLauncherManager.getInstalledApps()
            _installedApps.value = apps
        }
    }

    private fun startStatsTicker() {
        viewModelScope.launch {
            while (true) {
                val stats = SystemInfoHelper.getStats(getApplication())
                _uiState.value = _uiState.value.copy(stats = stats)
                delay(1000)
            }
        }
    }

    private fun displayWelcomeBanner() {
        val banner = listOf(
            TerminalLine(
                text = "========================================",
                type = LineType.BANNER
            ),
            TerminalLine(
                text = "  __  __            ___                   ",
                type = LineType.BANNER
            ),
            TerminalLine(
                text = " |  \\/  |__ _  __  | _ \\__ _ _ _ _  __ _ ",
                type = LineType.BANNER
            ),
            TerminalLine(
                text = " | |\\/| / _` |/ _| |   / _` | '_| || / _`|",
                type = LineType.BANNER
            ),
            TerminalLine(
                text = " |_|  |_\\__,_|\\__| |_|_\\__,_|_|  \\_,_\\__,_|",
                type = LineType.BANNER
            ),
            TerminalLine(
                text = " MACDONALD ARUFERA TERMINAL LAUNCHER v2.4",
                type = LineType.SUCCESS
            ),
            TerminalLine(
                text = "========================================",
                type = LineType.BANNER
            ),
            TerminalLine(
                text = "Type 'help' for manual, 'apps' for drawer, 'cmatrix' for digital rain.",
                type = LineType.SYSTEM
            ),
            TerminalLine(
                text = "Direct shell commands enabled. Try 'uname -a', 'date', 'sysinfo'.",
                type = LineType.SYSTEM
            )
        )
        _uiState.value = _uiState.value.copy(lines = banner)
    }

    fun onInputChange(newInput: String) {
        _uiState.value = _uiState.value.copy(input = newInput, historyIndex = -1)
    }

    fun submitCommand() {
        val rawCommand = _uiState.value.input.trim()
        if (rawCommand.isEmpty()) return

        // Check for aliases
        val matchedAlias = aliases.value.firstOrNull { it.name.equals(rawCommand, ignoreCase = true) }
        val resolvedCommand = matchedAlias?.expansion ?: rawCommand

        // Add to history
        viewModelScope.launch {
            historyDao.insert(CommandHistoryEntity(command = rawCommand))
        }
        localHistoryCache.add(0, rawCommand)

        // Append user command line
        val commandLine = TerminalLine(
            text = "arufera@macdonald:~$ $rawCommand",
            type = LineType.COMMAND
        )

        val updatedLines = _uiState.value.lines.toMutableList()
        updatedLines.add(commandLine)
        _uiState.value = _uiState.value.copy(lines = updatedLines, input = "", historyIndex = -1)

        // Process command
        executeInternalCommand(resolvedCommand)
    }

    private fun executeInternalCommand(command: String) {
        val parts = command.split("\\s+".toRegex()).filter { it.isNotEmpty() }
        if (parts.isEmpty()) return

        val cmd = parts[0].lowercase(Locale.ROOT)
        val args = parts.drop(1)

        when (cmd) {
            "help", "?" -> showHelp()
            "clear", "cls" -> clearScreen()
            "arufera", "banner" -> displayWelcomeBanner()
            "sysinfo", "neofetch" -> showNeofetch()
            "cmatrix" -> handleCMatrix(args)
            "apps", "list" -> handleAppsCommand(args)
            "open", "launch", "start" -> handleLaunchCommand(args)
            "appinfo" -> handleAppInfoCommand(args)
            "uninstall" -> handleUninstallCommand(args)
            "theme" -> handleThemeCommand(args)
            "calc" -> handleCalcCommand(args)
            "battery" -> showBatteryDetails()
            "wifi", "net" -> showNetworkDetails()
            "history" -> showHistory()
            "alias" -> handleAliasCommand(args)
            "unalias" -> handleUnaliasCommand(args)
            "scanlines" -> toggleScanlines()
            "exit" -> appendOutput("Use home gesture to return to home or 'clear' to clear scrollback.", LineType.SYSTEM)
            else -> {
                // Check if user simply typed an app name (e.g. "chrome", "settings", "camera")
                val matchedApp = appLauncherManager.findAppByName(command, _installedApps.value)
                if (matchedApp != null && parts.size <= 2) {
                    val launched = appLauncherManager.launchApp(matchedApp.packageName)
                    if (launched) {
                        appendOutput("Launching application: ${matchedApp.label}...", LineType.SUCCESS)
                    } else {
                        appendOutput("Failed to launch ${matchedApp.label}", LineType.ERROR)
                    }
                } else {
                    // Fallback to real Linux shell execution!
                    executeShellCommand(command)
                }
            }
        }
    }

    private fun executeShellCommand(command: String) {
        viewModelScope.launch {
            _uiState.value = _uiState.value.copy(isExecuting = true)
            val result = shellExecutor.execute(command)
            _uiState.value = _uiState.value.copy(isExecuting = false)

            val newLines = mutableListOf<TerminalLine>()
            if (result.output.isNotEmpty()) {
                result.output.forEach { line ->
                    newLines.add(TerminalLine(text = line, type = LineType.OUTPUT))
                }
            }
            if (result.error.isNotEmpty()) {
                result.error.forEach { errLine ->
                    newLines.add(TerminalLine(text = errLine, type = LineType.ERROR))
                }
            }
            if (result.exitCode != 0 && result.error.isEmpty()) {
                newLines.add(TerminalLine(text = "[Process exited with code ${result.exitCode}]", type = LineType.ERROR))
            }
            if (result.output.isEmpty() && result.error.isEmpty() && result.exitCode == 0) {
                newLines.add(TerminalLine(text = "[Success - Exit code 0]", type = LineType.SUCCESS))
            }

            appendLines(newLines)
        }
    }

    private fun showHelp() {
        val helpText = listOf(
            "=== MACDONALD ARUFERA TERMINAL MANUAL ===",
            "LAUNCHER COMMANDS:",
            "  apps [filter]      : List installed apps (clickable)",
            "  open <app>         : Launch installed app by name/package",
            "  appinfo <app>      : Open system settings for app",
            "  uninstall <app>    : Request uninstallation of app",
            "  [APPS] button      : Open visual cyberpunk app drawer",
            "",
            "CMATRIX COMMANDS:",
            "  cmatrix            : Toggle full-screen interactive digital rain",
            "  cmatrix on / off   : Toggle wallpaper digital rain",
            "  cmatrix speed <0.5-3.0>: Set falling speed (e.g. 'cmatrix speed 2')",
            "  cmatrix color <green|cyan|amber|red|purple>",
            "  cmatrix alpha <0.1-1.0>: Set background rain opacity",
            "",
            "SYSTEM & UTILITY COMMANDS:",
            "  sysinfo / neofetch : Hardware, Kernel, RAM, Uptime specs",
            "  battery            : Battery percentage, charging status",
            "  wifi / net         : Network connection & local IP address",
            "  calc <expression>  : Calculate math (e.g. 'calc (250*4)+12')",
            "  clear              : Clear terminal screen",
            "  theme <color>      : Change terminal color theme",
            "  scanlines          : Toggle CRT scanline effect",
            "  history            : View previous commands",
            "  alias <name=cmd>   : Create command alias",
            "",
            "LINUX SHELL:",
            "  Any standard Linux commands run directly in Android environment:",
            "  uname -a, df -h, ls -la, ps, date, echo, pwd, cat, id, whoami"
        )
        appendLines(helpText.map { TerminalLine(text = it, type = LineType.OUTPUT) })
    }

    private fun showNeofetch() {
        val stats = SystemInfoHelper.getStats(getApplication())
        val lines = listOf(
            "         /\\         arufera@macdonald",
            "        /  \\        -----------------",
            "       / /\\ \\       OS: Android ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})",
            "      / /  \\ \\      Model: ${Build.MANUFACTURER.replaceFirstChar { it.uppercase() }} ${Build.MODEL}",
            "     / / /\\ \\ \\     Kernel: ${System.getProperty("os.arch")} Linux ${System.getProperty("os.version")}",
            "    / / /  \\ \\ \\    Uptime: ${stats.uptimeFormatted}",
            "   /_/ / /\\ \\ \\_\\   Shell: MacDonald Arufera sh v2.4",
            "     \\_\\/  \\/_/     Terminal: Matrix CRT [${uiState.value.matrixTheme.label}]",
            "                    Battery: ${stats.batteryPercent}% ${if (stats.isCharging) "(Charging ⚡)" else ""}",
            "                    RAM: ${stats.usedRamMb}MB / ${stats.totalRamMb}MB",
            "                    Storage: ${stats.freeStorageGb}GB free / ${stats.totalStorageGb}GB",
            "                    IP: ${stats.ipAddress} (${stats.networkStatus})"
        )
        appendLines(lines.map { TerminalLine(text = it, type = LineType.OUTPUT) })
    }

    private fun handleCMatrix(args: List<String>) {
        if (args.isEmpty()) {
            // Toggle fullscreen cmatrix
            _uiState.value = _uiState.value.copy(isFullScreenMatrix = !_uiState.value.isFullScreenMatrix)
            return
        }

        when (args[0].lowercase()) {
            "on" -> {
                _uiState.value = _uiState.value.copy(isMatrixBackgroundEnabled = true)
                appendOutput("CMatrix digital rain: ENABLED", LineType.SUCCESS)
            }
            "off" -> {
                _uiState.value = _uiState.value.copy(isMatrixBackgroundEnabled = false)
                appendOutput("CMatrix digital rain: DISABLED", LineType.SYSTEM)
            }
            "speed" -> {
                val speed = args.getOrNull(1)?.toFloatOrNull() ?: 1.0f
                _uiState.value = _uiState.value.copy(matrixSpeed = speed.coerceIn(0.2f, 5.0f))
                appendOutput("CMatrix speed set to ${uiState.value.matrixSpeed}x", LineType.SUCCESS)
            }
            "color", "theme" -> {
                val colorArg = args.getOrNull(1)?.lowercase() ?: ""
                val theme = when (colorArg) {
                    "green", "matrix" -> MatrixColorTheme.PHOSPHOR_GREEN
                    "cyan", "blue" -> MatrixColorTheme.CYBER_CYAN
                    "amber", "orange", "gold" -> MatrixColorTheme.AMBER_GOLD
                    "red" -> MatrixColorTheme.BLOOD_RED
                    "purple", "violet", "synth" -> MatrixColorTheme.VIOLET_SYNTH
                    else -> MatrixColorTheme.PHOSPHOR_GREEN
                }
                _uiState.value = _uiState.value.copy(matrixTheme = theme)
                appendOutput("CMatrix theme switched to ${theme.label}", LineType.SUCCESS)
            }
            "alpha", "opacity" -> {
                val alpha = args.getOrNull(1)?.toFloatOrNull() ?: 0.4f
                _uiState.value = _uiState.value.copy(matrixOpacity = alpha.coerceIn(0.05f, 1.0f))
                appendOutput("CMatrix opacity set to ${uiState.value.matrixOpacity}", LineType.SUCCESS)
            }
            "full", "screensaver" -> {
                _uiState.value = _uiState.value.copy(isFullScreenMatrix = true)
            }
            else -> {
                appendOutput("Usage: cmatrix [on|off|speed <float>|color <green|cyan|amber|red|purple>|alpha <0.1-1.0>]", LineType.SYSTEM)
            }
        }
    }

    private fun handleAppsCommand(args: List<String>) {
        val filter = args.joinToString(" ").trim().lowercase()
        val filtered = if (filter.isEmpty()) {
            _installedApps.value
        } else {
            _installedApps.value.filter {
                it.label.lowercase().contains(filter) || it.packageName.lowercase().contains(filter)
            }
        }

        if (filtered.isEmpty()) {
            appendOutput("No installed applications matching '$filter'", LineType.ERROR)
            return
        }

        val lines = mutableListOf<TerminalLine>()
        lines.add(TerminalLine(text = "INSTALLED APPLICATIONS (${filtered.size} items):", type = LineType.SYSTEM))
        filtered.take(60).forEachIndexed { index, app ->
            val numStr = String.format(Locale.ROOT, "[%02d]", index + 1)
            lines.add(
                TerminalLine(
                    text = "$numStr ${app.label.padEnd(24)} -> ${app.packageName}",
                    type = LineType.OUTPUT,
                    actionLabel = "LAUNCH ${app.label}",
                    executableAction = {
                        appLauncherManager.launchApp(app.packageName)
                    }
                )
            )
        }
        if (filtered.size > 60) {
            lines.add(TerminalLine(text = "... and ${filtered.size - 60} more. Use 'apps <search>' to filter.", type = LineType.SYSTEM))
        }
        lines.add(TerminalLine(text = "Tip: Tap any app row to launch it directly, or type 'open <name>'.", type = LineType.SYSTEM))
        appendLines(lines)
    }

    private fun handleLaunchCommand(args: List<String>) {
        if (args.isEmpty()) {
            appendOutput("Usage: open <app name or package name>", LineType.ERROR)
            return
        }
        val query = args.joinToString(" ")
        val app = appLauncherManager.findAppByName(query, _installedApps.value)
        if (app != null) {
            val launched = appLauncherManager.launchApp(app.packageName)
            if (launched) {
                appendOutput("Launched ${app.label} (${app.packageName})", LineType.SUCCESS)
            } else {
                appendOutput("Failed to launch ${app.label}", LineType.ERROR)
            }
        } else {
            appendOutput("Application '$query' not found. Type 'apps' to search installed packages.", LineType.ERROR)
        }
    }

    private fun handleAppInfoCommand(args: List<String>) {
        if (args.isEmpty()) {
            appendOutput("Usage: appinfo <app name>", LineType.ERROR)
            return
        }
        val query = args.joinToString(" ")
        val app = appLauncherManager.findAppByName(query, _installedApps.value)
        if (app != null) {
            appLauncherManager.openAppDetails(app.packageName)
            appendOutput("Opened system settings for ${app.label}", LineType.SUCCESS)
        } else {
            appendOutput("Application '$query' not found.", LineType.ERROR)
        }
    }

    private fun handleUninstallCommand(args: List<String>) {
        if (args.isEmpty()) {
            appendOutput("Usage: uninstall <app name>", LineType.ERROR)
            return
        }
        val query = args.joinToString(" ")
        val app = appLauncherManager.findAppByName(query, _installedApps.value)
        if (app != null) {
            appLauncherManager.requestUninstall(app.packageName)
            appendOutput("Triggered uninstall dialog for ${app.label}", LineType.SUCCESS)
        } else {
            appendOutput("Application '$query' not found.", LineType.ERROR)
        }
    }

    private fun handleThemeCommand(args: List<String>) {
        val colorArg = args.getOrNull(0)?.lowercase() ?: ""
        val theme = when (colorArg) {
            "green", "matrix" -> MatrixColorTheme.PHOSPHOR_GREEN
            "cyan", "blue" -> MatrixColorTheme.CYBER_CYAN
            "amber", "orange", "gold" -> MatrixColorTheme.AMBER_GOLD
            "red" -> MatrixColorTheme.BLOOD_RED
            "purple", "violet", "synth" -> MatrixColorTheme.VIOLET_SYNTH
            else -> {
                appendOutput("Themes available: green, cyan, amber, red, purple", LineType.SYSTEM)
                return
            }
        }
        _uiState.value = _uiState.value.copy(matrixTheme = theme)
        appendOutput("Terminal theme switched to: ${theme.label}", LineType.SUCCESS)
    }

    private fun handleCalcCommand(args: List<String>) {
        if (args.isEmpty()) {
            appendOutput("Usage: calc <expression> (e.g. calc (1024 * 768) / 2)", LineType.ERROR)
            return
        }
        val expr = args.joinToString(" ")
        val result = SystemInfoHelper.evaluateMath(expr)
        if (result != null) {
            val formatted = if (result % 1.0 == 0.0) result.toLong().toString() else result.toString()
            appendOutput("$expr = $formatted", LineType.SUCCESS)
        } else {
            appendOutput("Math evaluation error for expression '$expr'", LineType.ERROR)
        }
    }

    private fun showBatteryDetails() {
        val stats = SystemInfoHelper.getStats(getApplication())
        appendLines(listOf(
            TerminalLine(text = "=== BATTERY TELEMETRY ===", type = LineType.SYSTEM),
            TerminalLine(text = "Level      : ${stats.batteryPercent}%", type = LineType.OUTPUT),
            TerminalLine(text = "Status     : ${if (stats.isCharging) "Charging ⚡" else "Discharging"}", type = LineType.OUTPUT)
        ))
    }

    private fun showNetworkDetails() {
        val stats = SystemInfoHelper.getStats(getApplication())
        appendLines(listOf(
            TerminalLine(text = "=== NETWORK INTERFACE ===", type = LineType.SYSTEM),
            TerminalLine(text = "Status     : ${stats.networkStatus}", type = LineType.OUTPUT),
            TerminalLine(text = "IPv4 Addr  : ${stats.ipAddress}", type = LineType.OUTPUT)
        ))
    }

    private fun showHistory() {
        val hist = commandHistory.value.take(20)
        if (hist.isEmpty()) {
            appendOutput("Command history is empty.", LineType.SYSTEM)
            return
        }
        val lines = mutableListOf<TerminalLine>()
        lines.add(TerminalLine(text = "COMMAND HISTORY:", type = LineType.SYSTEM))
        hist.forEachIndexed { idx, item ->
            lines.add(TerminalLine(text = " ${idx + 1}  ${item.command}", type = LineType.OUTPUT))
        }
        appendLines(lines)
    }

    private fun handleAliasCommand(args: List<String>) {
        if (args.isEmpty()) {
            val aliasList = aliases.value
            if (aliasList.isEmpty()) {
                appendOutput("No active aliases defined. Define one with 'alias name=command'.", LineType.SYSTEM)
            } else {
                val lines = mutableListOf<TerminalLine>()
                lines.add(TerminalLine(text = "ACTIVE ALIASES:", type = LineType.SYSTEM))
                aliasList.forEach { a ->
                    lines.add(TerminalLine(text = "  ${a.name}='${a.expansion}'", type = LineType.OUTPUT))
                }
                appendLines(lines)
            }
            return
        }

        val joined = args.joinToString(" ")
        if (!joined.contains('=')) {
            appendOutput("Usage: alias <name>=<command> (e.g. alias ll=ls -la)", LineType.ERROR)
            return
        }

        val split = joined.split('=', limit = 2)
        val name = split[0].trim()
        val expansion = split[1].trim().trim('\'', '\"')
        viewModelScope.launch {
            aliasDao.insertOrUpdate(AliasEntity(name, expansion))
        }
        appendOutput("Alias defined: $name='$expansion'", LineType.SUCCESS)
    }

    private fun handleUnaliasCommand(args: List<String>) {
        if (args.isEmpty()) {
            appendOutput("Usage: unalias <name>", LineType.ERROR)
            return
        }
        val name = args[0].trim()
        viewModelScope.launch {
            aliasDao.delete(name)
        }
        appendOutput("Alias '$name' removed.", LineType.SUCCESS)
    }

    private fun toggleScanlines() {
        _uiState.value = _uiState.value.copy(isCrtScanlines = !_uiState.value.isCrtScanlines)
        appendOutput("CRT scanline shader: ${if (uiState.value.isCrtScanlines) "ON" else "OFF"}", LineType.SYSTEM)
    }

    fun navigateHistory(up: Boolean) {
        val history = commandHistory.value
        if (history.isEmpty()) return

        var newIdx = if (up) {
            if (_uiState.value.historyIndex == -1) 0 else (_uiState.value.historyIndex + 1).coerceAtMost(history.size - 1)
        } else {
            if (_uiState.value.historyIndex <= 0) -1 else _uiState.value.historyIndex - 1
        }

        val text = if (newIdx >= 0 && newIdx < history.size) {
            history[newIdx].command
        } else {
            ""
        }
        _uiState.value = _uiState.value.copy(historyIndex = newIdx, input = text)
    }

    fun handleAutoComplete() {
        val current = _uiState.value.input.trim()
        if (current.isEmpty()) return

        val commands = listOf(
            "help", "clear", "arufera", "sysinfo", "neofetch", "cmatrix", "apps",
            "open", "appinfo", "uninstall", "theme", "calc", "battery", "wifi",
            "history", "alias", "unalias", "scanlines", "uname", "df", "ps", "uptime", "date"
        )

        // Try completing command
        val cmdMatch = commands.firstOrNull { it.startsWith(current, ignoreCase = true) }
        if (cmdMatch != null && cmdMatch.length > current.length) {
            _uiState.value = _uiState.value.copy(input = cmdMatch)
            return
        }

        // Try completing app name
        if (current.startsWith("open ") || current.startsWith("launch ")) {
            val appPrefix = current.substringAfter(" ").trim()
            val matchedApp = _installedApps.value.firstOrNull { it.label.startsWith(appPrefix, ignoreCase = true) }
            if (matchedApp != null) {
                val base = current.substringBefore(" ")
                _uiState.value = _uiState.value.copy(input = "$base ${matchedApp.label}")
                return
            }
        }
    }

    fun toggleAppDrawer(show: Boolean? = null) {
        val newState = show ?: !_uiState.value.showAppDrawer
        _uiState.value = _uiState.value.copy(showAppDrawer = newState)
    }

    fun toggleFullScreenMatrix(full: Boolean? = null) {
        val newState = full ?: !_uiState.value.isFullScreenMatrix
        _uiState.value = _uiState.value.copy(isFullScreenMatrix = newState)
    }

    fun setMatrixTheme(theme: MatrixColorTheme) {
        _uiState.value = _uiState.value.copy(matrixTheme = theme)
    }

    fun setMatrixSpeed(speed: Float) {
        _uiState.value = _uiState.value.copy(matrixSpeed = speed)
    }

    fun setMatrixOpacity(opacity: Float) {
        _uiState.value = _uiState.value.copy(matrixOpacity = opacity)
    }

    fun setMatrixBackgroundEnabled(enabled: Boolean) {
        _uiState.value = _uiState.value.copy(isMatrixBackgroundEnabled = enabled)
    }

    fun clearScreen() {
        _uiState.value = _uiState.value.copy(lines = emptyList())
    }

    private fun appendOutput(text: String, type: LineType) {
        appendLines(listOf(TerminalLine(text = text, type = type)))
    }

    private fun appendLines(newLines: List<TerminalLine>) {
        val list = _uiState.value.lines.toMutableList()
        list.addAll(newLines)
        // Keep max 500 lines
        if (list.size > 500) {
            list.subList(0, list.size - 500).clear()
        }
        _uiState.value = _uiState.value.copy(lines = list)
    }
}
