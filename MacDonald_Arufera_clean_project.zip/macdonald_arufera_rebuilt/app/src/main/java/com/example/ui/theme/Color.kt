package com.example.ui.theme

import androidx.compose.ui.graphics.Color

val MatrixGreen = Color(0xFF00FF66)
val MatrixGreenDark = Color(0xFF003814)
val MatrixGreenLead = Color(0xFFE8FFF0)

val MatrixBlack = Color(0xFF040805)
val MatrixSurface = Color(0xFF08120B)
val MatrixSurfaceVariant = Color(0xFF0D1C12)

val MatrixCyan = Color(0xFF00E5FF)
val MatrixAmber = Color(0xFFFFB300)
val MatrixRed = Color(0xFFFF3366)
val MatrixPurple = Color(0xFFCC44FF)
