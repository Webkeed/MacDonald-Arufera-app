package com.example.matrix

import android.graphics.Paint
import android.graphics.Typeface
import androidx.compose.animation.core.withInfiniteAnimationFrameMillis
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.graphics.toArgb
import androidx.compose.ui.input.pointer.pointerInput
import kotlin.random.Random

enum class MatrixColorTheme(val label: String, val primary: Color, val leadColor: Color, val darkColor: Color) {
    PHOSPHOR_GREEN("Matrix Green", Color(0xFF00FF66), Color(0xFFE8FFF0), Color(0xFF003814)),
    CYBER_CYAN("Cyber Cyan", Color(0xFF00E5FF), Color(0xFFE0F7FA), Color(0xFF002F38)),
    AMBER_GOLD("Amber Retro", Color(0xFFFFB300), Color(0xFFFFF8E1), Color(0xFF3E2700)),
    BLOOD_RED("Red Alert", Color(0xFFFF3366), Color(0xFFFFEBEE), Color(0xFF3E000C)),
    VIOLET_SYNTH("Synthwave Purple", Color(0xFFCC44FF), Color(0xFFF3E5F5), Color(0xFF2A003B))
}

class MatrixDrop(
    var col: Int,
    var y: Float,
    var speed: Float,
    var length: Int,
    var chars: MutableList<Char>
)

@Composable
fun MatrixRainBackground(
    modifier: Modifier = Modifier,
    speedMultiplier: Float = 1.0f,
    fontSizePx: Float = 36f,
    colorTheme: MatrixColorTheme = MatrixColorTheme.PHOSPHOR_GREEN,
    alpha: Float = 0.45f,
    isFullScreen: Boolean = false
) {
    val glyphPool = remember {
        "ｦｱｳｴｵｶｷｹｺｻｼｽｾｿﾀﾂﾃﾅﾆﾇﾈﾊﾋﾎﾏﾐﾑﾒﾓﾔﾕﾗﾘﾜ0123456789ABCDEF$#@%&*+=<>~/{}".toCharArray()
    }

    // Interactive disturbance points
    val shockwaves = remember { mutableStateListOf<Pair<Float, Float>>() }

    val nativePaintLead = remember(colorTheme) {
        Paint().apply {
            isAntiAlias = true
            textSize = fontSizePx
            typeface = Typeface.MONOSPACE
            color = colorTheme.leadColor.toArgb()
            setShadowLayer(fontSizePx * 0.4f, 0f, 0f, colorTheme.primary.toArgb())
        }
    }

    val nativePaintTrail = remember(colorTheme) {
        Paint().apply {
            isAntiAlias = true
            textSize = fontSizePx
            typeface = Typeface.MONOSPACE
            color = colorTheme.primary.toArgb()
        }
    }

    var frameTick by remember { mutableFloatStateOf(0f) }
    var screenWidth by remember { mutableFloatStateOf(1080f) }
    var screenHeight by remember { mutableFloatStateOf(1920f) }

    val drops = remember { mutableListOf<MatrixDrop>() }
    val columnWidth = fontSizePx * 0.95f
    var initializedForWidth by remember { mutableFloatStateOf(0f) }

    fun initColumns(width: Float, height: Float) {
        drops.clear()
        val numColumns = (width / columnWidth).toInt().coerceAtLeast(1)
        for (i in 0 until numColumns) {
            val length = Random.nextInt(10, 28)
            val chars = MutableList(length) { glyphPool[Random.nextInt(glyphPool.size)] }
            val drop = MatrixDrop(
                col = i,
                y = Random.nextFloat() * -height - Random.nextFloat() * 500f,
                speed = (Random.nextFloat() * 4f + 3.5f) * speedMultiplier,
                length = length,
                chars = chars
            )
            drops.add(drop)
        }
        initializedForWidth = width
    }

    // Animation driver loop
    LaunchedEffect(speedMultiplier) {
        while (true) {
            withInfiniteAnimationFrameMillis {
                frameTick += 1f
            }
        }
    }

    Canvas(
        modifier = modifier
            .fillMaxSize()
            .pointerInput(Unit) {
                detectTapGestures { offset ->
                    shockwaves.add(offset.x to offset.y)
                    if (shockwaves.size > 8) shockwaves.removeAt(0)
                }
            }
            .pointerInput(Unit) {
                detectDragGestures { change, _ ->
                    shockwaves.add(change.position.x to change.position.y)
                    if (shockwaves.size > 8) shockwaves.removeAt(0)
                }
            }
    ) {
        screenWidth = size.width
        screenHeight = size.height

        if (initializedForWidth != size.width && size.width > 0f) {
            initColumns(size.width, size.height)
        }

        // Draw deep ambient black backing if full screen
        if (isFullScreen) {
            drawRect(Color(0xFF030504))
        }

        val nativeCanvas = drawContext.canvas.nativeCanvas

        // Apply alpha multiplier
        nativePaintLead.alpha = (255 * (if (isFullScreen) 1.0f else alpha)).toInt().coerceIn(10, 255)

        for (drop in drops) {
            // Update drop position
            drop.y += drop.speed * (fontSizePx * 0.08f)
            if (drop.y - (drop.length * fontSizePx) > screenHeight) {
                drop.y = -Random.nextFloat() * 200f
                drop.speed = (Random.nextFloat() * 4f + 3.5f) * speedMultiplier
                drop.length = Random.nextInt(10, 28)
                drop.chars = MutableList(drop.length) { glyphPool[Random.nextInt(glyphPool.size)] }
            }

            // Mutation chance
            if (Random.nextFloat() < 0.08f && drop.chars.isNotEmpty()) {
                val mutateIdx = Random.nextInt(drop.chars.size)
                drop.chars[mutateIdx] = glyphPool[Random.nextInt(glyphPool.size)]
            }

            val x = drop.col * columnWidth

            // Draw glyph trail
            for (j in 0 until drop.length) {
                val charY = drop.y - (j * fontSizePx)
                if (charY in -fontSizePx..(screenHeight + fontSizePx)) {
                    val char = if (j < drop.chars.size) drop.chars[j] else glyphPool[0]

                    if (j == 0) {
                        // Leading head character: bright white/lead neon
                        nativeCanvas.drawText(char.toString(), x, charY, nativePaintLead)
                    } else {
                        // Trailing characters fade from bright to faint
                        val fadeFactor = (1.0f - (j.toFloat() / drop.length)).coerceIn(0.12f, 0.9f)
                        val trailAlpha = (255 * fadeFactor * (if (isFullScreen) 0.95f else alpha)).toInt()
                        nativePaintTrail.alpha = trailAlpha.coerceIn(5, 255)
                        nativeCanvas.drawText(char.toString(), x, charY, nativePaintTrail)
                    }
                }
            }
        }
    }
}
