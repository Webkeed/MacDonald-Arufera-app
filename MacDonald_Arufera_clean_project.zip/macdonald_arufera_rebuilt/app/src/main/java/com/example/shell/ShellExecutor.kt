package com.example.shell

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.BufferedReader
import java.io.File
import java.io.InputStreamReader

data class CommandResult(
    val output: List<String>,
    val error: List<String>,
    val exitCode: Int,
    val timedOut: Boolean = false
)

class ShellExecutor(private val context: Context) {
    private val workingDir: File = context.filesDir

    suspend fun execute(command: String, timeoutMs: Long = 10000): CommandResult = withContext(Dispatchers.IO) {
        val stdoutList = mutableListOf<String>()
        val stderrList = mutableListOf<String>()
        var exitCode = -1

        try {
            val process = ProcessBuilder("sh", "-c", command)
                .directory(workingDir)
                .redirectErrorStream(false)
                .start()

            val completed = withTimeoutOrNull(timeoutMs) {
                val outReader = BufferedReader(InputStreamReader(process.inputStream))
                val errReader = BufferedReader(InputStreamReader(process.errorStream))

                var line: String?
                while (outReader.readLine().also { line = it } != null) {
                    stdoutList.add(line ?: "")
                }
                while (errReader.readLine().also { line = it } != null) {
                    stderrList.add(line ?: "")
                }

                exitCode = process.waitFor()
                true
            }

            if (completed == null) {
                process.destroy()
                return@withContext CommandResult(
                    output = stdoutList,
                    error = stderrList + listOf("Execution timed out after ${timeoutMs / 1000}s"),
                    exitCode = 124,
                    timedOut = true
                )
            }

            CommandResult(
                output = stdoutList,
                error = stderrList,
                exitCode = exitCode
            )
        } catch (e: Exception) {
            CommandResult(
                output = emptyList(),
                error = listOf("Shell error: ${e.message ?: e.javaClass.simpleName}"),
                exitCode = 1
            )
        }
    }
}
