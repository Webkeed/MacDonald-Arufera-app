package com.example.shell

enum class LineType {
    COMMAND,
    OUTPUT,
    ERROR,
    SUCCESS,
    SYSTEM,
    BANNER
}

data class TerminalLine(
    val id: String = java.util.UUID.randomUUID().toString(),
    val text: String,
    val type: LineType = LineType.OUTPUT,
    val timestamp: Long = System.currentTimeMillis(),
    val executableAction: (() -> Unit)? = null,
    val actionLabel: String? = null
)
