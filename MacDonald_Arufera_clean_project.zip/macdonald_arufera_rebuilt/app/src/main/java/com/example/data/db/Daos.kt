package com.example.data.db

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface HistoryDao {
    @Query("SELECT * FROM command_history ORDER BY id DESC LIMIT 200")
    fun getAllHistory(): Flow<List<CommandHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(item: CommandHistoryEntity)

    @Query("DELETE FROM command_history")
    suspend fun clearHistory()
}

@Dao
interface AliasDao {
    @Query("SELECT * FROM aliases ORDER BY name ASC")
    fun getAllAliases(): Flow<List<AliasEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdate(alias: AliasEntity)

    @Query("DELETE FROM aliases WHERE name = :name")
    suspend fun delete(name: String)
}
