package com.example.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [CommandHistoryEntity::class, AliasEntity::class], version = 1, exportSchema = false)
abstract class AruferaDatabase : RoomDatabase() {
    abstract fun historyDao(): HistoryDao
    abstract fun aliasDao(): AliasDao

    companion object {
        @Volatile
        private var INSTANCE: AruferaDatabase? = null

        fun getInstance(context: Context): AruferaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AruferaDatabase::class.java,
                    "arufera_terminal.db"
                ).fallbackToDestructiveMigration().build()
                INSTANCE = instance
                instance
            }
        }
    }
}
