package com.example.ui

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.matrix.MatrixColorTheme
import com.example.matrix.MatrixRainBackground
import com.example.shell.TerminalUiState
import com.example.shell.TerminalViewModel

@Composable
fun CMatrixFullScreen(
    uiState: TerminalUiState,
    viewModel: TerminalViewModel,
    onDismiss: () -> Unit
) {
    var showHud by remember { mutableStateOf(true) }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF030504))
            .testTag("cmatrix_fullscreen_screen")
    ) {
        // Digital Rain Canvas
        MatrixRainBackground(
            modifier = Modifier.fillMaxSize(),
            speedMultiplier = uiState.matrixSpeed,
            colorTheme = uiState.matrixTheme,
            alpha = 1.0f,
            isFullScreen = true
        )

        // HUD Overlay
        AnimatedVisibility(
            visible = showHud,
            enter = fadeIn(),
            exit = fadeOut(),
            modifier = Modifier.fillMaxSize()
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .statusBarsPadding()
                    .padding(16.dp),
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // Top Header HUD
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Color(0xCC050A07),
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            uiState.matrixTheme.primary.copy(alpha = 0.5f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 14.dp, vertical = 10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "MACDONALD ARUFERA",
                            color = uiState.matrixTheme.leadColor,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            letterSpacing = 1.5.sp
                        )
                        Text(
                            text = "CMATRIX DIGITAL RAIN CORE",
                            color = uiState.matrixTheme.primary,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            letterSpacing = 1.sp
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            text = uiState.stats?.currentTime ?: "--:--:--",
                            color = uiState.matrixTheme.leadColor,
                            fontFamily = FontFamily.Monospace,
                            fontWeight = FontWeight.Bold,
                            fontSize = 14.sp
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        IconButton(
                            onClick = onDismiss,
                            modifier = Modifier
                                .size(36.dp)
                                .background(
                                    uiState.matrixTheme.primary.copy(alpha = 0.2f),
                                    RoundedCornerShape(6.dp)
                                )
                                .testTag("cmatrix_close_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "Close CMatrix",
                                tint = uiState.matrixTheme.leadColor,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Middle Info / Hint
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { showHud = !showHud },
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "TOUCH TO DISTURB THE CODE STREAM\nTAP HUD BUTTONS TO CONTROL ENGINE",
                        color = uiState.matrixTheme.primary.copy(alpha = 0.7f),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 11.sp,
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center,
                        lineHeight = 18.sp
                    )
                }

                // Bottom Controls Bar
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .background(
                            Color(0xDD050A07),
                            RoundedCornerShape(8.dp)
                        )
                        .border(
                            1.dp,
                            uiState.matrixTheme.primary.copy(alpha = 0.5f),
                            RoundedCornerShape(8.dp)
                        )
                        .padding(horizontal = 12.dp, vertical = 8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Speed controls
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Speed,
                            contentDescription = null,
                            tint = uiState.matrixTheme.primary,
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "${String.format("%.1f", uiState.matrixSpeed)}x",
                            color = uiState.matrixTheme.leadColor,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Box(
                            modifier = Modifier
                                .background(uiState.matrixTheme.primary.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                                .border(1.dp, uiState.matrixTheme.primary.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                .clickable {
                                    val newSpeed = (uiState.matrixSpeed - 0.5f).coerceAtLeast(0.5f)
                                    viewModel.setMatrixSpeed(newSpeed)
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("-", color = uiState.matrixTheme.leadColor, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                        }
                        Spacer(modifier = Modifier.width(6.dp))
                        Box(
                            modifier = Modifier
                                .background(uiState.matrixTheme.primary.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                                .border(1.dp, uiState.matrixTheme.primary.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                                .clickable {
                                    val newSpeed = (uiState.matrixSpeed + 0.5f).coerceAtMost(4.0f)
                                    viewModel.setMatrixSpeed(newSpeed)
                                }
                                .padding(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("+", color = uiState.matrixTheme.leadColor, fontFamily = FontFamily.Monospace, fontSize = 13.sp)
                        }
                    }

                    // Theme selector button
                    Row(
                        modifier = Modifier
                            .background(uiState.matrixTheme.primary.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                            .border(1.dp, uiState.matrixTheme.primary.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
                            .clickable {
                                val themes = MatrixColorTheme.entries.toTypedArray()
                                val nextIdx = (themes.indexOf(uiState.matrixTheme) + 1) % themes.size
                                viewModel.setMatrixTheme(themes[nextIdx])
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = uiState.matrixTheme.leadColor,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = uiState.matrixTheme.label.uppercase(),
                            color = uiState.matrixTheme.leadColor,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    // Exit button
                    Box(
                        modifier = Modifier
                            .background(Color(0xFF330009), RoundedCornerShape(4.dp))
                            .border(1.dp, Color(0xFFFF3366).copy(alpha = 0.6f), RoundedCornerShape(4.dp))
                            .clickable { onDismiss() }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = "EXIT",
                            color = Color(0xFFFF7799),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
