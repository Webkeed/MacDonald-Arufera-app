package com.example.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.matrix.MatrixColorTheme
import com.example.shell.TerminalUiState
import com.example.shell.TerminalViewModel

@Composable
fun TerminalSettingsDialog(
    uiState: TerminalUiState,
    viewModel: TerminalViewModel,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF080F0A),
        modifier = Modifier.testTag("settings_dialog"),
        title = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "TERMINAL CONFIG",
                        color = uiState.matrixTheme.leadColor,
                        fontFamily = FontFamily.Monospace,
                        fontWeight = FontWeight.Bold,
                        fontSize = 16.sp
                    )
                    Text(
                        text = "MACDONALD ARUFERA CORE",
                        color = uiState.matrixTheme.primary,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
                IconButton(onClick = onDismiss, modifier = Modifier.size(32.dp)) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = uiState.matrixTheme.primary
                    )
                }
            }
        },
        text = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
            ) {
                // Theme Picker
                Text(
                    text = "COLOR MATRIX PALETTE",
                    color = uiState.matrixTheme.primary,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    MatrixColorTheme.entries.forEach { theme ->
                        val isSelected = uiState.matrixTheme == theme
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(
                                    if (isSelected) theme.primary.copy(alpha = 0.25f) else Color(0xFF0D1711),
                                    RoundedCornerShape(6.dp)
                                )
                                .border(
                                    1.dp,
                                    if (isSelected) theme.primary else Color(0x2200FF66),
                                    RoundedCornerShape(6.dp)
                                )
                                .clickable { viewModel.setMatrixTheme(theme) }
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(14.dp)
                                    .background(theme.primary, RoundedCornerShape(3.dp))
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = theme.label,
                                color = if (isSelected) theme.leadColor else Color.LightGray,
                                fontFamily = FontFamily.Monospace,
                                fontSize = 12.sp,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Rain Background Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "Background CMatrix Rain",
                            color = uiState.matrixTheme.leadColor,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Animated falls behind terminal",
                            color = uiState.matrixTheme.primary.copy(alpha = 0.7f),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = uiState.isMatrixBackgroundEnabled,
                        onCheckedChange = { viewModel.setMatrixBackgroundEnabled(it) },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = uiState.matrixTheme.leadColor,
                            checkedTrackColor = uiState.matrixTheme.primary
                        )
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Rain Speed Slider
                Text(
                    text = "Rain Speed: ${String.format("%.1f", uiState.matrixSpeed)}x",
                    color = uiState.matrixTheme.leadColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
                Slider(
                    value = uiState.matrixSpeed,
                    onValueChange = { viewModel.setMatrixSpeed(it) },
                    valueRange = 0.5f..3.5f,
                    colors = SliderDefaults.colors(
                        thumbColor = uiState.matrixTheme.leadColor,
                        activeTrackColor = uiState.matrixTheme.primary
                    )
                )

                Spacer(modifier = Modifier.height(10.dp))

                // Rain Opacity Slider
                Text(
                    text = "Rain Opacity: ${(uiState.matrixOpacity * 100).toInt()}%",
                    color = uiState.matrixTheme.leadColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp
                )
                Slider(
                    value = uiState.matrixOpacity,
                    onValueChange = { viewModel.setMatrixOpacity(it) },
                    valueRange = 0.1f..0.85f,
                    colors = SliderDefaults.colors(
                        thumbColor = uiState.matrixTheme.leadColor,
                        activeTrackColor = uiState.matrixTheme.primary
                    )
                )

                Spacer(modifier = Modifier.height(14.dp))

                // CRT Scanlines Toggle
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = "CRT Phosphor Scanlines",
                            color = uiState.matrixTheme.leadColor,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 12.sp
                        )
                        Text(
                            text = "Authentic retro monitor overlay",
                            color = uiState.matrixTheme.primary.copy(alpha = 0.7f),
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp
                        )
                    }
                    Switch(
                        checked = uiState.isCrtScanlines,
                        onCheckedChange = { viewModel.submitCommand() /* scanlines */ },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = uiState.matrixTheme.leadColor,
                            checkedTrackColor = uiState.matrixTheme.primary
                        )
                    )
                }
            }
        },
        confirmButton = {
            TextButton(onClick = onDismiss) {
                Text("DONE", color = uiState.matrixTheme.leadColor, fontFamily = FontFamily.Monospace)
            }
        }
    )
}
