package com.example.ui

import android.content.Context
import android.os.VibrationEffect
import android.os.Vibrator
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BatteryChargingFull
import androidx.compose.material.icons.filled.BatteryFull
import androidx.compose.material.icons.filled.DeleteSweep
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.matrix.MatrixRainBackground
import com.example.shell.LineType
import com.example.shell.TerminalLine
import com.example.shell.TerminalViewModel

@Composable
fun TerminalScreen(
    viewModel: TerminalViewModel
) {
    val uiState by viewModel.uiState.collectAsState()
    val installedApps by viewModel.installedApps.collectAsState()
    val listState = rememberLazyListState()
    val focusRequester = remember { FocusRequester() }
    val context = LocalContext.current
    var showSettingsDialog by remember { mutableStateOf(false) }

    fun vibrate() {
        try {
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            vibrator?.let {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    it.vibrate(VibrationEffect.createOneShot(25, VibrationEffect.DEFAULT_AMPLITUDE))
                } else {
                    @Suppress("DEPRECATION")
                    it.vibrate(25)
                }
            }
        } catch (_: Exception) {}
    }

    // Auto-scroll on new lines
    LaunchedEffect(uiState.lines.size) {
        if (uiState.lines.isNotEmpty()) {
            listState.animateScrollToItem(uiState.lines.size - 1)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF040805))
            .testTag("terminal_main_screen")
    ) {
        // Background Matrix Rain
        if (uiState.isMatrixBackgroundEnabled) {
            MatrixRainBackground(
                modifier = Modifier.fillMaxSize(),
                speedMultiplier = uiState.matrixSpeed,
                colorTheme = uiState.matrixTheme,
                alpha = uiState.matrixOpacity,
                isFullScreen = false
            )
        }

        // CRT Scanline Shader Overlay
        if (uiState.isCrtScanlines) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                val step = 4.dp.toPx()
                var y = 0f
                while (y < size.height) {
                    drawLine(
                        color = Color(0x15000000),
                        start = Offset(0f, y),
                        end = Offset(size.width, y),
                        strokeWidth = 1.5f
                    )
                    y += step
                }
            }
        }

        // Terminal Content Column
        Column(
            modifier = Modifier
                .fillMaxSize()
                .statusBarsPadding()
                .navigationBarsPadding()
                .imePadding()
        ) {
            // Header Bar
            TerminalHeader(
                uiState = uiState,
                onOpenMatrix = {
                    vibrate()
                    viewModel.toggleFullScreenMatrix(true)
                },
                onOpenApps = {
                    vibrate()
                    viewModel.toggleAppDrawer(true)
                },
                onOpenSettings = {
                    vibrate()
                    showSettingsDialog = true
                },
                onClear = {
                    vibrate()
                    viewModel.clearScreen()
                }
            )

            // Terminal Scrollback Area
            SelectionContainer(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 4.dp)
            ) {
                LazyColumn(
                    state = listState,
                    modifier = Modifier
                        .fillMaxSize()
                        .testTag("terminal_scrollback_list"),
                    verticalArrangement = Arrangement.spacedBy(3.dp)
                ) {
                    items(uiState.lines, key = { it.id }) { line ->
                        TerminalLineItem(
                            line = line,
                            uiState = uiState,
                            onExecuteAction = {
                                vibrate()
                                line.executableAction?.invoke()
                            }
                        )
                    }
                }
            }

            // Hacker Key Row (Tab, Up, Down, Quick Commands)
            HackerKeyRow(
                uiState = uiState,
                onTab = {
                    vibrate()
                    viewModel.handleAutoComplete()
                },
                onUp = {
                    vibrate()
                    viewModel.navigateHistory(true)
                },
                onDown = {
                    vibrate()
                    viewModel.navigateHistory(false)
                },
                onInsertKey = { key ->
                    vibrate()
                    viewModel.onInputChange(uiState.input + key)
                },
                onQuickCommand = { cmd ->
                    vibrate()
                    viewModel.onInputChange(cmd)
                    viewModel.submitCommand()
                }
            )

            // Terminal Command Input Field
            TerminalInputBar(
                uiState = uiState,
                focusRequester = focusRequester,
                onInputChange = { viewModel.onInputChange(it) },
                onSubmit = {
                    vibrate()
                    viewModel.submitCommand()
                }
            )
        }

        // Fullscreen CMatrix Mode
        if (uiState.isFullScreenMatrix) {
            CMatrixFullScreen(
                uiState = uiState,
                viewModel = viewModel,
                onDismiss = {
                    vibrate()
                    viewModel.toggleFullScreenMatrix(false)
                }
            )
        }

        // App Drawer Bottom Sheet
        if (uiState.showAppDrawer) {
            AppDrawerSheet(
                apps = installedApps,
                appLauncherManager = viewModel.appLauncherManager,
                matrixTheme = uiState.matrixTheme,
                onDismiss = {
                    vibrate()
                    viewModel.toggleAppDrawer(false)
                }
            )
        }

        // Settings Dialog
        if (showSettingsDialog) {
            TerminalSettingsDialog(
                uiState = uiState,
                viewModel = viewModel,
                onDismiss = { showSettingsDialog = false }
            )
        }
    }
}

@Composable
private fun TerminalHeader(
    uiState: com.example.shell.TerminalUiState,
    onOpenMatrix: () -> Unit,
    onOpenApps: () -> Unit,
    onOpenSettings: () -> Unit,
    onClear: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xCC050E08))
            .border(
                1.dp,
                uiState.matrixTheme.primary.copy(alpha = 0.35f),
                RoundedCornerShape(bottomStart = 8.dp, bottomEnd = 8.dp)
            )
            .padding(horizontal = 12.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        // App Title & Telemetry
        Column {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .background(uiState.matrixTheme.primary, RoundedCornerShape(2.dp))
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = "MACDONALD ARUFERA",
                    color = uiState.matrixTheme.leadColor,
                    fontFamily = FontFamily.Monospace,
                    fontWeight = FontWeight.Bold,
                    fontSize = 13.sp,
                    letterSpacing = 1.sp
                )
            }

            // Stats row (RAM, Battery, Time)
            Row(
                modifier = Modifier.padding(top = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = uiState.stats?.currentTime ?: "--:--:--",
                    color = uiState.matrixTheme.primary.copy(alpha = 0.8f),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 10.sp
                )
                Spacer(modifier = Modifier.width(8.dp))
                uiState.stats?.let { stats ->
                    Icon(
                        imageVector = if (stats.isCharging) Icons.Default.BatteryChargingFull else Icons.Default.BatteryFull,
                        contentDescription = null,
                        tint = uiState.matrixTheme.primary,
                        modifier = Modifier.size(12.dp)
                    )
                    Spacer(modifier = Modifier.width(2.dp))
                    Text(
                        text = "${stats.batteryPercent}%",
                        color = uiState.matrixTheme.primary.copy(alpha = 0.8f),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "RAM:${stats.usedRamMb}M",
                        color = uiState.matrixTheme.primary.copy(alpha = 0.7f),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp
                    )
                }
            }
        }

        // Action Toolbar
        Row(
            horizontalArrangement = Arrangement.spacedBy(6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            // Fullscreen CMatrix button
            HeaderChip(
                label = "MATRIX",
                color = uiState.matrixTheme.primary,
                textColor = uiState.matrixTheme.leadColor,
                onClick = onOpenMatrix,
                testTag = "header_matrix_button"
            )

            // App Drawer button
            HeaderChip(
                label = "APPS",
                color = uiState.matrixTheme.primary,
                textColor = uiState.matrixTheme.leadColor,
                onClick = onOpenApps,
                testTag = "header_apps_button"
            )

            // Clear button
            IconButton(
                onClick = onClear,
                modifier = Modifier
                    .size(30.dp)
                    .background(Color(0xFF0C1710), RoundedCornerShape(4.dp))
                    .border(1.dp, uiState.matrixTheme.primary.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                    .testTag("header_clear_button")
            ) {
                Icon(
                    imageVector = Icons.Default.DeleteSweep,
                    contentDescription = "Clear screen",
                    tint = uiState.matrixTheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }

            // Settings button
            IconButton(
                onClick = onOpenSettings,
                modifier = Modifier
                    .size(30.dp)
                    .background(Color(0xFF0C1710), RoundedCornerShape(4.dp))
                    .border(1.dp, uiState.matrixTheme.primary.copy(alpha = 0.3f), RoundedCornerShape(4.dp))
                    .testTag("header_settings_button")
            ) {
                Icon(
                    imageVector = Icons.Default.Settings,
                    contentDescription = "Settings",
                    tint = uiState.matrixTheme.primary,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
private fun HeaderChip(
    label: String,
    color: Color,
    textColor: Color,
    onClick: () -> Unit,
    testTag: String
) {
    Box(
        modifier = Modifier
            .background(color.copy(alpha = 0.2f), RoundedCornerShape(4.dp))
            .border(1.dp, color.copy(alpha = 0.4f), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 5.dp)
            .testTag(testTag)
    ) {
        Text(
            text = label,
            color = textColor,
            fontFamily = FontFamily.Monospace,
            fontSize = 10.sp,
            fontWeight = FontWeight.Bold
        )
    }
}

@Composable
private fun TerminalLineItem(
    line: TerminalLine,
    uiState: com.example.shell.TerminalUiState,
    onExecuteAction: () -> Unit
) {
    when (line.type) {
        LineType.COMMAND -> {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = line.text,
                    color = uiState.matrixTheme.leadColor,
                    fontFamily = FontFamily.Monospace,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }
        LineType.BANNER -> {
            Text(
                text = line.text,
                color = uiState.matrixTheme.primary,
                fontFamily = FontFamily.Monospace,
                fontSize = 11.sp,
                lineHeight = 14.sp
            )
        }
        LineType.SUCCESS -> {
            Text(
                text = line.text,
                color = Color(0xFF00FF7F),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp,
                fontWeight = FontWeight.SemiBold
            )
        }
        LineType.ERROR -> {
            Text(
                text = line.text,
                color = Color(0xFFFF5252),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp
            )
        }
        LineType.SYSTEM -> {
            Text(
                text = line.text,
                color = Color(0xFF00E5FF),
                fontFamily = FontFamily.Monospace,
                fontSize = 12.sp
            )
        }
        LineType.OUTPUT -> {
            if (line.executableAction != null && line.actionLabel != null) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = line.text,
                        color = Color(0xFFD4E6D9),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 12.sp,
                        modifier = Modifier.weight(1f)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Box(
                        modifier = Modifier
                            .background(uiState.matrixTheme.primary.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                            .border(1.dp, uiState.matrixTheme.primary.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                            .clickable { onExecuteAction() }
                            .padding(horizontal = 6.dp, vertical = 2.dp)
                    ) {
                        Text(
                            text = "LAUNCH",
                            color = uiState.matrixTheme.leadColor,
                            fontFamily = FontFamily.Monospace,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            } else {
                Text(
                    text = line.text,
                    color = Color(0xFFD4E6D9),
                    fontFamily = FontFamily.Monospace,
                    fontSize = 12.sp,
                    lineHeight = 16.sp
                )
            }
        }
    }
}

@Composable
private fun HackerKeyRow(
    uiState: com.example.shell.TerminalUiState,
    onTab: () -> Unit,
    onUp: () -> Unit,
    onDown: () -> Unit,
    onInsertKey: (String) -> Unit,
    onQuickCommand: (String) -> Unit
) {
    val scrollState = rememberScrollState()
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xE6050C07))
            .border(
                1.dp,
                uiState.matrixTheme.primary.copy(alpha = 0.2f),
                RoundedCornerShape(0.dp)
            )
            .horizontalScroll(scrollState)
            .padding(horizontal = 8.dp, vertical = 5.dp),
        horizontalArrangement = Arrangement.spacedBy(6.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        KeyChip(label = "TAB", onClick = onTab, color = uiState.matrixTheme.primary)
        KeyChip(label = "↑", onClick = onUp, color = uiState.matrixTheme.primary)
        KeyChip(label = "↓", onClick = onDown, color = uiState.matrixTheme.primary)
        KeyChip(label = "cmatrix", onClick = { onQuickCommand("cmatrix") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "apps", onClick = { onQuickCommand("apps") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "neofetch", onClick = { onQuickCommand("neofetch") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "clear", onClick = { onQuickCommand("clear") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "help", onClick = { onQuickCommand("help") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "|", onClick = { onInsertKey(" | ") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "-", onClick = { onInsertKey("-") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "/", onClick = { onInsertKey("/") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "~", onClick = { onInsertKey("~") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "uname -a", onClick = { onQuickCommand("uname -a") }, color = uiState.matrixTheme.primary)
        KeyChip(label = "df -h", onClick = { onQuickCommand("df -h") }, color = uiState.matrixTheme.primary)
    }
}

@Composable
private fun KeyChip(
    label: String,
    onClick: () -> Unit,
    color: Color
) {
    Box(
        modifier = Modifier
            .background(Color(0xFF0D1711), RoundedCornerShape(4.dp))
            .border(1.dp, color.copy(alpha = 0.35f), RoundedCornerShape(4.dp))
            .clickable { onClick() }
            .padding(horizontal = 8.dp, vertical = 4.dp)
    ) {
        Text(
            text = label,
            color = Color(0xFFBCE8C5),
            fontFamily = FontFamily.Monospace,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium
        )
    }
}

@Composable
private fun TerminalInputBar(
    uiState: com.example.shell.TerminalUiState,
    focusRequester: FocusRequester,
    onInputChange: (String) -> Unit,
    onSubmit: () -> Unit
) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .background(Color(0xFF08120B))
            .border(
                1.dp,
                uiState.matrixTheme.primary.copy(alpha = 0.4f),
                RoundedCornerShape(0.dp)
            )
            .padding(horizontal = 10.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = "arufera@macdonald:~$ ",
            color = uiState.matrixTheme.primary,
            fontFamily = FontFamily.Monospace,
            fontSize = 12.sp,
            fontWeight = FontWeight.Bold
        )

        BasicTextField(
            value = uiState.input,
            onValueChange = onInputChange,
            singleLine = true,
            textStyle = TextStyle(
                color = Color.White,
                fontFamily = FontFamily.Monospace,
                fontSize = 13.sp
            ),
            cursorBrush = SolidColor(uiState.matrixTheme.primary),
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Ascii,
                imeAction = ImeAction.Send,
                autoCorrectEnabled = false
            ),
            keyboardActions = KeyboardActions(onSend = { onSubmit() }),
            modifier = Modifier
                .weight(1f)
                .focusRequester(focusRequester)
                .testTag("terminal_command_input"),
            decorationBox = { innerTextField ->
                if (uiState.input.isEmpty()) {
                    Text(
                        text = "command or app name...",
                        color = Color(0x44FFFFFF),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 13.sp
                    )
                }
                innerTextField()
            }
        )

        Spacer(modifier = Modifier.width(6.dp))

        if (uiState.isExecuting) {
            CircularProgressIndicator(
                color = uiState.matrixTheme.primary,
                strokeWidth = 2.dp,
                modifier = Modifier.size(20.dp)
            )
        } else {
            IconButton(
                onClick = onSubmit,
                modifier = Modifier
                    .size(32.dp)
                    .background(uiState.matrixTheme.primary.copy(alpha = 0.25f), RoundedCornerShape(4.dp))
                    .border(1.dp, uiState.matrixTheme.primary.copy(alpha = 0.5f), RoundedCornerShape(4.dp))
                    .testTag("terminal_send_button")
            ) {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "Execute Command",
                    tint = uiState.matrixTheme.leadColor,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}
