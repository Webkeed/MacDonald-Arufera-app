package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material3.Surface
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import com.example.shell.TerminalViewModel
import com.example.ui.TerminalScreen
import com.example.ui.theme.MatrixBlack
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {

    private val viewModel: TerminalViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                val uiState by viewModel.uiState.collectAsState()

                // Handle back gestures smoothly for launcher navigation
                BackHandler(enabled = uiState.isFullScreenMatrix || uiState.showAppDrawer) {
                    if (uiState.isFullScreenMatrix) {
                        viewModel.toggleFullScreenMatrix(false)
                    } else if (uiState.showAppDrawer) {
                        viewModel.toggleAppDrawer(false)
                    }
                }

                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MatrixBlack
                ) {
                    TerminalScreen(viewModel = viewModel)
                }
            }
        }
    }
}
