package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = MatrixGreen,
    onPrimary = Color(0xFF003814),
    primaryContainer = Color(0xFF005220),
    onPrimaryContainer = MatrixGreenLead,
    secondary = MatrixCyan,
    onSecondary = Color(0xFF00363D),
    tertiary = MatrixAmber,
    background = MatrixBlack,
    onBackground = Color(0xFFE1E3DF),
    surface = MatrixSurface,
    onSurface = Color(0xFFE1E3DF),
    surfaceVariant = MatrixSurfaceVariant,
    onSurfaceVariant = Color(0xFFC0C9C0),
    error = MatrixRed,
    onError = Color.White
)

@Composable
fun MyApplicationTheme(
    content: @Composable () -> Unit
) {
    MaterialTheme(
        colorScheme = DarkColorScheme,
        typography = Typography,
        content = content
    )
}
