# MacDonald Arufera Android Project

This is the cleaned project source.

## Goal
Build an installable APK for an Android phone.

## Important
A ZIP/project is not itself installable. The final artifact must be an `.apk`.

## Build
Use an Android-compatible build environment/CI service to run the Gradle wrapper and create the debug APK.
The APK is normally produced under the app module's `build/outputs/apk/` directory.
